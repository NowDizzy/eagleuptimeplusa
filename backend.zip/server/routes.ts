import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertProjectSchema } from "@shared/schema";
import multer from "multer";
import fs from "fs";
import path from "path";
import AdmZip from "adm-zip";
import { botService } from "./bot-service";

// Ensure uploads directory exists
const uploadDir = 'uploads';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

const upload = multer({ 
  dest: uploadDir,
  fileFilter: (_req, file, cb) => {
    if (file.mimetype !== 'application/zip' && !file.originalname.endsWith('.zip')) {
      cb(new Error('Sadece .zip dosyaları yüklenebilir'));
      return;
    }
    cb(null, true);
  },
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB limit
  }
});

async function searchRequiredFiles(zipPath: string): Promise<{
  hasAppJs: boolean;
  hasBotJs: boolean;
  hasIndexJs: boolean;
  hasStartBat: boolean;
}> {
  const zip = new AdmZip(zipPath);
  const entries = zip.getEntries();

  return {
    hasAppJs: entries.some(entry => entry.entryName.toLowerCase().endsWith('app.js')),
    hasBotJs: entries.some(entry => entry.entryName.toLowerCase().endsWith('bot.js')),
    hasIndexJs: entries.some(entry => entry.entryName.toLowerCase().endsWith('index.js')),
    hasStartBat: entries.some(entry => entry.entryName.toLowerCase().endsWith('start.bat'))
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Projects
  app.get("/api/projects", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const projects = await storage.getProjects(req.user.id);
    res.json(projects);
  });

  app.post("/api/projects", upload.single('project'), async (req, res) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      if (!req.file) return res.status(400).send("Lütfen bir zip dosyası yükleyin");

      const result = insertProjectSchema.safeParse(req.body);
      if (!result.success) {
        fs.unlinkSync(req.file.path);
        return res.status(400).json(result.error);
      }

      // Check for required files
      const files = await searchRequiredFiles(req.file.path);
      if (!files.hasAppJs && !files.hasBotJs && !files.hasIndexJs && !files.hasStartBat) {
        fs.unlinkSync(req.file.path);
        return res.status(400).send("Zip dosyası içinde start.bat, app.js, bot.js veya index.js dosyalarından en az biri bulunmalıdır");
      }

      // Create project first
      const project = await storage.createProject(req.user.id, result.data.name);
      await storage.updateProjectStatus(project.id, "uploading");

      try {
        // Set up project directory
        const projectDir = path.join(uploadDir, project.id.toString());
        if (!fs.existsSync(projectDir)) {
          fs.mkdirSync(projectDir);
        }

        // Extract files
        const zip = new AdmZip(req.file.path);
        zip.extractAllTo(projectDir, true);

        // Move original zip to storage
        const newPath = path.join(uploadDir, `${project.id}.zip`);
        fs.renameSync(req.file.path, newPath);

        // Update project status
        await storage.updateProjectStatus(project.id, "extracted");

        // If bot token is provided, save it
        if (result.data.botToken) {
          await storage.updateProjectBotToken(project.id, result.data.botToken);
          await storage.updateProjectStatus(project.id, "configured");

          // Try to start the bot
          try {
            await botService.startBot(project);
          } catch (error) {
            console.error(`Failed to start bot: ${error.message}`);
            await storage.updateProjectStatus(project.id, "start_failed");
          }
        }

        res.status(201).json(project);
      } catch (error) {
        await storage.updateProjectStatus(project.id, "failed");
        throw error;
      }
    } catch (error) {
      if (req.file && fs.existsSync(req.file.path)) {
        fs.unlinkSync(req.file.path);
      }
      console.error('Project upload error:', error);
      res.status(500).send(error.message || "Dosya yükleme hatası");
    }
  });

  app.delete("/api/projects/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const projectId = parseInt(req.params.id);

      // Stop the bot if it's running
      await botService.stopBot(projectId);

      // Delete the associated zip file and extracted directory
      const zipPath = path.join(uploadDir, `${projectId}.zip`);
      const projectDir = path.join(uploadDir, projectId.toString());

      if (fs.existsSync(zipPath)) {
        fs.unlinkSync(zipPath);
      }
      if (fs.existsSync(projectDir)) {
        fs.rmSync(projectDir, { recursive: true, force: true });
      }

      await storage.deleteProject(projectId, req.user.id);
      res.sendStatus(200);
    } catch (error) {
      console.error('Project deletion error:', error);
      res.status(500).send("Proje silme hatası");
    }
  });

  // Bot management
  app.post("/api/projects/:id/start", async (req, res) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const projectId = parseInt(req.params.id);
      const projects = await storage.getProjects(req.user.id);
      const project = projects.find(p => p.id === projectId);

      if (!project) {
        return res.status(404).send("Proje bulunamadı");
      }

      await botService.startBot(project);
      res.sendStatus(200);
    } catch (error) {
      console.error('Bot start error:', error);
      res.status(500).send(error.message);
    }
  });

  app.post("/api/projects/:id/stop", async (req, res) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const projectId = parseInt(req.params.id);
      const projects = await storage.getProjects(req.user.id);
      const project = projects.find(p => p.id === projectId);

      if (!project) {
        return res.status(404).send("Proje bulunamadı");
      }

      await botService.stopBot(project.id);
      res.sendStatus(200);
    } catch (error) {
      console.error('Bot stop error:', error);
      res.status(500).send(error.message);
    }
  });

  app.post("/api/projects/:id/restart", async (req, res) => {
    try {
      if (!req.isAuthenticated()) return res.sendStatus(401);
      const projectId = parseInt(req.params.id);
      const projects = await storage.getProjects(req.user.id);
      const project = projects.find(p => p.id === projectId);

      if (!project) {
        return res.status(404).send("Proje bulunamadı");
      }

      await botService.restartBot(project);
      res.sendStatus(200);
    } catch (error) {
      console.error('Bot restart error:', error);
      res.status(500).send(error.message);
    }
  });

  // API Keys
  app.get("/api/keys", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const keys = await storage.getApiKeys(req.user.id);
    res.json(keys);
  });

  app.post("/api/keys", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const apiKey = await storage.createApiKey(req.user.id);
    res.status(201).json(apiKey);
  });

  const httpServer = createServer(app);
  return httpServer;
}